"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SelfAuthorizer = exports.AdminAuthorizer = exports.Authorizer = void 0;
const services_1 = require("../services");
const models_1 = require("../models");
const BEARER_TOKEN_PATTERN = /^Bearer[ ]+([^ ]+)[ ]*$/i;
const extractAccessToken = (authorization) => {
    if (!authorization)
        return null;
    const result = BEARER_TOKEN_PATTERN.exec(authorization);
    if (!result)
        return null;
    return result[1];
};
exports.Authorizer = (req) => __awaiter(void 0, void 0, void 0, function* () {
    const authorizationHeader = req.headers['Authorization'];
    const accessToken = extractAccessToken(authorizationHeader);
    if (!accessToken)
        throw { status: 401, message: 'Invalid Bearer Token' };
    const verified = services_1.verifyToken(accessToken);
    const { models } = yield models_1.connectDatabase();
    const user = yield models.User.findOne({ where: { id: verified === null || verified === void 0 ? void 0 : verified.id } });
    if (user) {
        return user;
    }
    else {
        throw { status: 401, message: 'NotFound User' };
    }
});
exports.AdminAuthorizer = (req) => __awaiter(void 0, void 0, void 0, function* () {
    const user = yield exports.Authorizer(req);
    const isAdmin = (user === null || user === void 0 ? void 0 : user.role) === 'admin';
    if (isAdmin) {
        return user;
    }
    else {
        throw {
            status: 401,
            message: 'Authorization Failure: No Admin Permission',
        };
    }
});
exports.SelfAuthorizer = (req, compareUser) => __awaiter(void 0, void 0, void 0, function* () {
    const user = yield exports.Authorizer(req);
    if ((user === null || user === void 0 ? void 0 : user.id) === (compareUser === null || compareUser === void 0 ? void 0 : compareUser.id) || (user === null || user === void 0 ? void 0 : user.role) === 'admin') {
        return user;
    }
    else {
        throw { status: 401, message: 'Authorization Failure: No Permission' };
    }
});
//# sourceMappingURL=auth.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MYSQL = exports.JWT_SECRET = void 0;
const getEnvValue = (key, type = 'string') => {
    const value = process.env[key];
    if (!value)
        throw { status: 500, message: 'env error' };
    if (type === 'boolean') {
        return value.toLowerCase() === 'true';
    }
    if (type === 'number') {
        const parsedInt = parseInt(value);
        if (parsedInt) {
            return parsedInt;
        }
        else {
            throw { status: 500, message: 'env error' };
        }
    }
    if (type === 'string')
        return value;
    throw { status: 500, message: 'env type error' };
};
exports.JWT_SECRET = getEnvValue('JWT_SECRET', 'string');
exports.MYSQL = {
    host: getEnvValue('MYSQL_HOST', 'string'),
    user: getEnvValue('MYSQL_USER', 'string'),
    password: getEnvValue('MYSQL_PASSWORD', 'string'),
    database: getEnvValue('MYSQL_DATABASE', 'string'),
    logging: getEnvValue('MYSQL_LOGGING', 'boolean'),
    synchronize: getEnvValue('MYSQL_SYNC', 'boolean'),
};
//# sourceMappingURL=index.js.map
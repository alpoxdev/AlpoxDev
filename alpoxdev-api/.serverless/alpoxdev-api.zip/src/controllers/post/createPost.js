"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPost = void 0;
const services_1 = require("../../services");
const models_1 = require("../../models");
const middlewares_1 = require("../../middlewares");
exports.createPost = services_1.createGatewayProxyHandler((req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { title, content, thumbnail, tags } = req.body;
    const { models } = yield models_1.connectDatabase();
    const user = yield middlewares_1.AdminAuthorizer(req);
    const post = new models_1.Post();
    post.title = title;
    post.content = content;
    post.thumbnail = thumbnail;
    post.user = user;
    post.tags = yield tryFindOrCreateTags(tags);
    yield models.Post.save(post);
    return res({ status: 201, body: { post } });
}));
const tryFindOrCreateTags = (tags) => { var tags_1, tags_1_1; return __awaiter(void 0, void 0, void 0, function* () {
    var e_1, _a;
    if (!tags)
        return [];
    const findOrCreateTags = [];
    try {
        for (tags_1 = __asyncValues(tags); tags_1_1 = yield tags_1.next(), !tags_1_1.done;) {
            const tag = tags_1_1.value;
            const findOrCreateTag = yield tryFindOrCreateTag(tag);
            findOrCreateTags.push(findOrCreateTag);
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (tags_1_1 && !tags_1_1.done && (_a = tags_1.return)) yield _a.call(tags_1);
        }
        finally { if (e_1) throw e_1.error; }
    }
    return findOrCreateTags.filter((tag) => tag !== null);
}); };
const tryFindOrCreateTag = (tag) => __awaiter(void 0, void 0, void 0, function* () {
    if (typeof tag === 'number') {
        const findTag = yield models_1.Tag.findOne(tag);
        if (!findTag)
            throw { status: 404, message: 'NotFound tag' };
        return findTag;
    }
    if (typeof tag === 'string') {
        const findTag = yield models_1.Tag.findOne({ where: { tag } });
        if (findTag)
            return findTag;
        const newTag = yield models_1.Tag.create({ tag }).save();
        return newTag;
    }
    return null;
});
//# sourceMappingURL=createPost.js.map
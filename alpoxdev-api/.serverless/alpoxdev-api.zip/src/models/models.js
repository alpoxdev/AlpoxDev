"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Tag = exports.Post = exports.User = void 0;
var user_1 = require("./user");
Object.defineProperty(exports, "User", { enumerable: true, get: function () { return user_1.default; } });
__exportStar(require("./user"), exports);
var post_1 = require("./post");
Object.defineProperty(exports, "Post", { enumerable: true, get: function () { return post_1.default; } });
var tag_1 = require("./tag");
Object.defineProperty(exports, "Tag", { enumerable: true, get: function () { return tag_1.default; } });
//# sourceMappingURL=models.js.map
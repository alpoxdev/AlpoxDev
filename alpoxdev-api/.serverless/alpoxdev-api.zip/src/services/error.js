"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getError = void 0;
const ERROR_MESSAGE = {
    400: 'BAD REQUEST',
    401: 'Authorization Failure',
    403: 'Forbidden',
    404: 'NotFound',
    500: 'Internal Server Error'
};
exports.getError = (status, message) => {
    const defaultMessage = ERROR_MESSAGE[status] || '';
    const body = {
        message: message ? message : defaultMessage
    };
    return {
        status,
        body
    };
};
//# sourceMappingURL=error.js.map
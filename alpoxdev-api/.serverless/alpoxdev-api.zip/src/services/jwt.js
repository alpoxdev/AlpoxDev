"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyToken = exports.signToken = void 0;
const jwt = require("jsonwebtoken");
const config_1 = require("../config");
const signToken = (userPayload) => {
    const token = jwt.sign(userPayload, config_1.JWT_SECRET);
    return token;
};
exports.signToken = signToken;
const verifyToken = (token) => {
    try {
        const payload = jwt.verify(token, config_1.JWT_SECRET);
        if (payload)
            return payload;
        throw { status: 401, message: 'Invalid Token' };
    }
    catch (error) {
        throw { status: 401, message: 'Invalid Token' };
    }
};
exports.verifyToken = verifyToken;
//# sourceMappingURL=jwt.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parsePageQuery = void 0;
exports.parsePageQuery = (params) => {
    const page = (params === null || params === void 0 ? void 0 : params.limit) || '0';
    const offset = (params === null || params === void 0 ? void 0 : params.offset) || '20';
    return {
        page: parseInt(page, 10),
        offset: parseInt(offset, 10)
    };
};
//# sourceMappingURL=query.js.map
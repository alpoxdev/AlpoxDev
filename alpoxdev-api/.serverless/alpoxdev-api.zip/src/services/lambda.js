"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createGatewayProxyHandler = void 0;
const error_1 = require("./error");
const query_1 = require("./query");
const getResponse = ({ status, body, headers }) => {
    let responseBody = '';
    if (typeof body === 'object') {
        responseBody = JSON.stringify(body);
    }
    if (typeof body === 'string') {
        responseBody = body;
    }
    return {
        statusCode: status,
        body: responseBody,
        headers: Object.assign({ 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, DELETE, PUT, PATCH, OPTIONS', 'Access-Control-Allow-Headers': '*' }, headers)
    };
};
exports.createGatewayProxyHandler = (handler) => {
    return (event) => __awaiter(void 0, void 0, void 0, function* () {
        const { body, headers, pathParameters, queryStringParameters } = event;
        const query = Object.assign(Object.assign({}, queryStringParameters), query_1.parsePageQuery(queryStringParameters));
        const req = {
            body: JSON.parse(body || '{}'),
            params: pathParameters,
            query,
            headers
        };
        const res = getResponse;
        try {
            return yield handler(req, res);
        }
        catch (error) {
            const { status = 404, body } = error_1.getError(error === null || error === void 0 ? void 0 : error.status, error === null || error === void 0 ? void 0 : error.message);
            console.log(status, body);
            return getResponse({
                status,
                body
            });
        }
    });
};
//# sourceMappingURL=lambda.js.map
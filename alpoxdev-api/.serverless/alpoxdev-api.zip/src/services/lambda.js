"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createGatewayProxyHandler = void 0;
const error_1 = require("./error");
const query_1 = require("./query");
const config_1 = require("../config");
const isProduction = config_1.NODE_ENV === 'prod';
const getResponse = ({ status, body, headers, }) => {
    let responseBody = '';
    if (typeof body === 'object') {
        responseBody = JSON.stringify(body);
    }
    if (typeof body === 'string') {
        responseBody = body;
    }
    return {
        statusCode: status,
        body: responseBody,
        headers: Object.assign({ 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, DELETE, PUT, PATCH, OPTIONS', 'Access-Control-Allow-Headers': '*' }, headers),
    };
};
exports.createGatewayProxyHandler = (handler) => {
    return (event) => __awaiter(void 0, void 0, void 0, function* () {
        const { body, headers, pathParameters, queryStringParameters } = event;
        const parsedQuery = parseQuery(queryStringParameters);
        const parsedBody = parseBody(body);
        const req = {
            params: pathParameters,
            query: parsedQuery,
            body: parsedBody,
            headers,
            event,
        };
        const res = getResponse;
        try {
            isProduction && console.log(`Lambda Request`, req);
            const response = yield handler(req, res);
            console.log(`Lambda Response`, response);
            return response;
        }
        catch (error) {
            const { status = 404, body } = error_1.getError(error === null || error === void 0 ? void 0 : error.status, error === null || error === void 0 ? void 0 : error.message);
            console.log(`Lambda Error`, error);
            return getResponse({
                status,
                body,
            });
        }
    });
};
const parseQuery = (query) => {
    return Object.assign(Object.assign({}, query), query_1.parsePageQuery(query));
};
const parseBody = (body) => {
    try {
        return JSON.parse(body || '{}');
    }
    catch (error) {
        return {};
    }
};
//# sourceMappingURL=lambda.js.map